---
crawl_start_datetime: "2026-07-12T04:21:46+00:00"
session_id: "session_deceit_upgrade"
stored_directory: "outputs/streamlit_sessions/session_deceit_upgrade/crawl_01_rumbling/2026-07-12_04-21-46/final"
crawl_parameters:
  crawler_config:
    urls:
      - "https://felixmobile.com.au/"
    exclude_paths: []
    include_only_paths:
      - "felixmobile.com.au"
    limit: 9999
    max_depth: 10
    max_concurrent: 5
    flush_interval: 5
    delay: 1.0
    stealth: true
    strip_www: false
    headers: {}
    max_retries: 5
    proxy_on_initial: false
  page_config:
    exclude_tags:
      - "nav"
      - "script"
      - "form"
      - "style"
    include_only_tags: []
    wait_until: "networkidle"
    wait_for: 3.0
    timeout: 60.0
    max_file_size_mb: 10.0
    extract_main_content: true
    output_extension: ".md"
    separate_items: true
    item_selector: ""
    js_code: []
    scan_full_page: true
    scroll_delay: 0.4
    ocr_languages:
      - "eng"
      - "msa"
    absolute_links: true
    flatten_shadow_dom: true
status: "failed"
---


---

<!-- crawl4md:source -->
# FAILED — Unexpected error in _crawl_web at line 778 in _crawl_web (../../../../anaconda3/lib/python3.12/site-packages/crawl4ai/async_crawler_strategy.py):
Error: Failed on navigating ACS-GOTO:
Page.goto: Timeout 60000ms exceeded.
Call log:
  - navigating to "https://felixmobile.com.au/triple-zero-update", waiting until "networkidle"


Code context:
 773                                   tag="GOTO",
 774                                   params={"url": url},
 775                               )
 776                               response = None
 777                           else:
 778 →                             raise RuntimeError(f"Failed on navigating ACS-GOTO:\n{str(e)}")
 779   
 780                       # ──────────────────────────────────────────────────────────────
 781                       # Walk the redirect chain.  Playwright returns only the last
 782                       # hop, so we trace the `request.redirected_from` links until the
 783                       # first response that differs from the final one and surface its

*Source: https://felixmobile.com.au/triple-zero-update*
<!-- /crawl4md:source -->

---

**Error:** Unexpected error in _crawl_web at line 778 in _crawl_web (../../../../anaconda3/lib/python3.12/site-packages/crawl4ai/async_crawler_strategy.py):
Error: Failed on navigating ACS-GOTO:
Page.goto: Timeout 60000ms exceeded.
Call log:
  - navigating to "https://felixmobile.com.au/triple-zero-update", waiting until "networkidle"


Code context:
 773                                   tag="GOTO",
 774                                   params={"url": url},
 775                               )
 776                               response = None
 777                           else:
 778 →                             raise RuntimeError(f"Failed on navigating ACS-GOTO:\n{str(e)}")
 779   
 780                       # ──────────────────────────────────────────────────────────────
 781                       # Walk the redirect chain.  Playwright returns only the last
 782                       # hop, so we trace the `request.redirected_from` links until the
 783                       # first response that differs from the final one and surface its

**Raw response:**

(no response)
